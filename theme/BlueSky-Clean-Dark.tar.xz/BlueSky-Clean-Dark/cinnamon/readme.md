# Credits

This themes base on <b>Arc-Theme</b> </br>
Links : https://github.com/horst3180/arc-theme</br>
License : GPLv3 (https://choosealicense.com/licenses/gpl-3.0/)</br>

# Installation

Cinnamon Themes : Extract Archive File On Directory /.themes or /usr/share/themes (as root) on Cinnamon Desktop Environment</br>
Have been tested on : Linux Mint Cinnamon 19 Tara</br>
Download themes : https://www.opendesktop.org/p/1279115/</br>

# Change the themes

"This is the themes of Cinnamon Desktop Environment</br>
Change the themes on Linux Mint (Cinnamon): Menu > Settings > Themes > Themes > Controls</br>
